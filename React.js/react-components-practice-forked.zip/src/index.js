import React from "react";
import ReactDOM from "react-dom";
import "./../public/styles.css";

ReactDOM.render(<App />, document.getElementById("root"));
