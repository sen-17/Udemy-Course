import React from "react";
import ReactDOM from "react-dom";

const fname = "Jasson";
const lname = "Tan";
const luck = Math.floor(Math.random() * 10);

ReactDOM.render(
  <div>
    <h1>Hello {`${fname} ${lname}`}</h1>
    <p>Your Lucky Number is {luck}</p>
  </div>,

  document.getElementById("root")
);
