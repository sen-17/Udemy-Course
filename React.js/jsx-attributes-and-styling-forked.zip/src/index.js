import React from "react";
import ReactDOM from "react-dom";

const img = "https://picsum.photos/200?grayscale";

ReactDOM.render(
  <div>
    <h1 className="test" contentEditable="true " spellCheck="false">
      My Favourite Foods
    </h1>
    <div>
      <img src={img} />
    </div>
  </div>,
  document.getElementById("root")
);
