import React from "react";

function Heading() {
  return <h1>My Favourite Foods</h1>;
}

export default Heading;
